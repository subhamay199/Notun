package com.cg.ticketing.daoservices;

import com.cg.ticketing.beans.ReservedTicket;

public interface ReservedBookingDAO {
	ReservedTicket save(ReservedTicket pnr);
	ReservedTicket findOne(ReservedTicket pnr);
	ReservedTicket delete(ReservedTicket pnr);
}
