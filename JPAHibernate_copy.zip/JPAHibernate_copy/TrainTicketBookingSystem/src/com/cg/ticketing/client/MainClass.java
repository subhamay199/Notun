package com.cg.ticketing.client;

import java.util.Scanner;

import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.exceptions.TicketUnavailableException;
import com.cg.ticketing.services.TicketingServices;
import com.cg.ticketing.services.TicketingServicesImpl;
import com.cg.ticketing.util.TrainTicketingDBUtil;

public class MainClass {
	public static void main(String[] args) throws TicketUnavailableException {
		Scanner sc = new Scanner(System.in);
		ReservedTicket reservedTicket = null;
		TicketingServices ticketingService=new TicketingServicesImpl();
		System.out.println("**This is a deluxe Journey-across-India ticketing system**");
		System.out.println("List of Journey Routes are:");
		System.out.println("\nRoute #1. Howrah - New delhi [Rs 1750]");
		System.out.println("\nRoute #2. New Delhi - CSM Terminal [Rs 2750]");
		System.out.println("\nRoute #3. CSM Terminal - Trivandrum [Rs 2150]");
		System.out.println("\nRoute #4. Trivandrum - Secunderabad [Rs 1550]");
		System.out.println("\nRoute #5. Secunderabad - Howrah [Rs 1050]");
		System.out.println("\n\n Enter your choice:");
		int ch=sc.nextInt();
		int currentPNR = 0;
		switch(ch) {
		case 1:	System.out.println("\n\n Enter your choice:");
						System.out.println("\nPress 1 for reserved booking:");
						System.out.println("\nPress 2 for unreserved booking:");
						int ch2=sc.nextInt();
						switch(ch2)
						{
						case 1:	reservedTicket.setDepartureStation("Howrah");
										reservedTicket.setArrivalStation("New Delhi");
										System.out.println("\nEnter Passenger Name:");
										String passengerName=sc.nextLine();
										reservedTicket.setName(passengerName);
										System.out.println("\nEnter Passenger Gender:");
										char gender=sc.next().charAt(0);
										reservedTicket.setGender(gender);
										System.out.println("\nEnter Passenger Age:");
										int age=sc.nextInt();
										reservedTicket.setAge(age);
										reservedTicket.setPrice(1750);
										reservedTicket.setPnr(TrainTicketingDBUtil.getPNR());
										currentPNR=reservedTicket.getPnr();
							ticketingService.bookReserved(reservedTicket);
						case 2:	ticketingService.cancelReserved(reservedTicket);
						}
						break;
					case 2: 		System.out.println("\n\n Enter your choice:");
										System.out.println("\nPress 1 for reserved booking:");
										System.out.println("\nPress 2 for unreserved booking:");
										int chh=sc.nextInt();
											switch(chh)
											{
											case 1:	reservedTicket.setDepartureStation("New Delhi");
															reservedTicket.setArrivalStation("CSM Terminal ");
															System.out.println("\nEnter Passenger Name:");
															String passengerName=sc.nextLine();
															reservedTicket.setName(passengerName);
															System.out.println("\nEnter Passenger Gender:");
															char gender=sc.next().charAt(0);
															reservedTicket.setGender(gender);
															System.out.println("\nEnter Passenger Age:");
															int age=sc.nextInt();
															reservedTicket.setAge(age);
															reservedTicket.setPrice(2750);
															reservedTicket.setPnr(TrainTicketingDBUtil.getPNR());
															currentPNR=reservedTicket.getPnr();
															ticketingService.bookReserved(reservedTicket);
												case 2:	ticketingService.cancelReserved(reservedTicket);
											}
							break;
					case 3: System.out.println("\n\n Enter your choice:");
									System.out.println("\nPress 1 for reserved booking:");
										System.out.println("\nPress 2 for unreserved booking:");
											int ch3=sc.nextInt();
												switch(ch3)
												{
												case 1:	reservedTicket.setDepartureStation("CSM Terminal");
																reservedTicket.setArrivalStation("Trivandrum");
																System.out.println("\nEnter Passenger Name:");
																String passengerName=sc.nextLine();
																reservedTicket.setName(passengerName);
																System.out.println("\nEnter Passenger Gender:");
																char gender=sc.next().charAt(0);
																reservedTicket.setGender(gender);
																System.out.println("\nEnter Passenger Age:");
																int age=sc.nextInt();
																reservedTicket.setAge(age);
																reservedTicket.setPrice(2150);
																reservedTicket.setPnr(TrainTicketingDBUtil.getPNR());
																currentPNR=reservedTicket.getPnr();
																ticketingService.bookReserved(reservedTicket);
													case 2:	ticketingService.cancelReserved(reservedTicket);
						}
						break;
					case 4: System.out.println("\n\n Enter your choice:");
									System.out.println("\nPress 1 for reserved booking:");
									System.out.println("\nPress 2 for unreserved booking:");
									int ch4=sc.nextInt();
									switch(ch4)
							{
							case 1:	reservedTicket.setDepartureStation("Trivandrum");
											reservedTicket.setArrivalStation("Secunderabad");
											System.out.println("\nEnter Passenger Name:");
											String passengerName=sc.nextLine();
											reservedTicket.setName(passengerName);
											System.out.println("\nEnter Passenger Gender:");
											char gender=sc.next().charAt(0);
											reservedTicket.setGender(gender);
											System.out.println("\nEnter Passenger Age:");
											int age=sc.nextInt();
											reservedTicket.setAge(age);
											reservedTicket.setPrice(1550);
											reservedTicket.setPnr(TrainTicketingDBUtil.getPNR());
											currentPNR=reservedTicket.getPnr();
											ticketingService.bookReserved(reservedTicket);
								case 2:	ticketingService.cancelReserved(reservedTicket);
				}
				break;
			case 5: System.out.println("\n\n Enter your choice:");
							System.out.println("\nPress 1 for reserved booking:");
							System.out.println("\nPress 2 for unreserved booking:");
							int ch5=sc.nextInt();
						switch(ch5)
							{
							case 1:	reservedTicket.setDepartureStation("Secunderabad");
											reservedTicket.setArrivalStation("Howrah");
											System.out.println("\nEnter Passenger Name:");
											String passengerName=sc.nextLine();
											reservedTicket.setName(passengerName);
											System.out.println("\nEnter Passenger Gender:");
											char gender=sc.next().charAt(0);
											reservedTicket.setGender(gender);
											System.out.println("\nEnter Passenger Age:");
											int age=sc.nextInt();
											reservedTicket.setAge(age);
											reservedTicket.setPrice(1050);
											reservedTicket.setPnr(TrainTicketingDBUtil.getPNR());
											currentPNR=reservedTicket.getPnr();
											ticketingService.bookReserved(reservedTicket);
						case 2:	ticketingService.cancelReserved(reservedTicket);
									}
				break;
		}
	}
}