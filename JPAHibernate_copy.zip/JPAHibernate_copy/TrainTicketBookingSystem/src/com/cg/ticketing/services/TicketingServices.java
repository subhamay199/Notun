package com.cg.ticketing.services;
import java.util.List;
import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.UnReservedTicket;
public interface TicketingServices {
ReservedTicket bookReserved(ReservedTicket currentPNR);
ReservedTicket cancelReserved(ReservedTicket currentPNR);
UnReservedTicket bookUnReserved(UnReservedTicket unReservedTicket);
UnReservedTicket cancelUnReserved(UnReservedTicket unReservedTicket);
}
