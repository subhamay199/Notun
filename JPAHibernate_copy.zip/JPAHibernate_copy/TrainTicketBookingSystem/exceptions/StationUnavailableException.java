package com.cg.ticketing.exceptions;

public class StationUnavailableException extends Exception {
public StationUnavailableException() {
 System.out.println("Station Is Not Avialable");	// TODO Auto-generated constructor stub
}
}
