package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl  implements PayrollServices{
	private AssociateDAO associateDao=new AssociateDAOImpl();
	public PayrollServicesImpl(AssociateDAO mockAssociateDao) {
		// TODO Auto-generated constructor stub
	}
	public PayrollServicesImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		Associate associate =new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode));
		associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public double calculateAnnualGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findOne(associateId);

		return ((associate.getSalary().getBasicSalary())+(0.3*(associate.getSalary().getBasicSalary())*2)+
				(0.25*(associate.getSalary().getBasicSalary()))+(0.2*(associate.getSalary().getBasicSalary()))+
				associate.getSalary().getCompanyPf()+associate.getSalary().getEpf())*12;
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		return calculateAnnualGrossSalary(associateId)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf();
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate Details not found for Id "+associateId);
		return associate;
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDao.findAll();
	}
	@Override
	public double taxCalculator(int associateId) {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate Details not found for Id "+associateId);
		double grossSal=calculateAnnualGrossSalary(associateId);
		if(grossSal<=250000)
			return 0;
		else if(grossSal>250000&& grossSal<=500000)
		{
			grossSal-=250000;
			return grossSal/10;
		}
		else if(grossSal>500000&& grossSal<=1000000)
		{
			grossSal-=500000;
			return grossSal/5+25000;
		}
		else 
		{
			grossSal-=1000000;
			return (grossSal*3/10)+50000+25000;
		}

	}
}