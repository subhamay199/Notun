package com.cg.banking.exceptions;
public class InvalidAccountTypeException extends RuntimeException{
	public InvalidAccountTypeException(){
		System.out.println("Invalid Account");
	}
}
